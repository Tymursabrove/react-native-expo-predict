export type TeamAbregsType = {
  [key: string]: string;
};
export type HomeCardContentsType = {
  [key: number]: {
    [key: string]: string;
  };
};
// export type AccountMenusType = {

// }
