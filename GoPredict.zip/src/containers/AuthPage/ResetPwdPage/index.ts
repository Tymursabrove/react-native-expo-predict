export { default as ResetPwdPage } from "./ResetPwdPage";
