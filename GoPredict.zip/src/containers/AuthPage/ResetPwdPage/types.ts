export type Props = {
  navigation: any;
  themeMode: string
};
