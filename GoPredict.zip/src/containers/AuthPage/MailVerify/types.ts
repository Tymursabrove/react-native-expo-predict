export type Props = {
  navigation: any;
  loginReuest: Function;
  loading: boolean;
  error: any;
  requestLogin: Function;
  themeMode: string
};
