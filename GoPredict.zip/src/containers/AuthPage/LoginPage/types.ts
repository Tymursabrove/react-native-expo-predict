export type Props = {
  navigation: any;
  loginReuest: Function;
  loading: string;
  error: any;
  requestLogin: Function;
  themeMode: string;
};
