import React, { useState, useEffect } from "react";
import { Box, Flex } from "@react-native-material/core";
import { Text } from "react-native-paper";
const Futures = () => {
    return (
        <Box>
            <Text style={{ fontSize: 20, margin: "auto" }}>Hello, Welcome to Futures Page.</Text>
        </Box>
    )
}

export default Futures;