import React, { useState, useEffect } from "react";
import { Box, Flex } from "@react-native-material/core";
import { Text } from "react-native-paper";
const Forex = () => {
    return (
        <Box>
            <Text style={{ fontSize: 20, margin: "auto" }}>Hello, Welcome to Forex Page.</Text>
        </Box>
    )
}

export default Forex;