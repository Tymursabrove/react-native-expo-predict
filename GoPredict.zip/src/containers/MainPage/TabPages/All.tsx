import React, { useState, useEffect } from "react";
import { Box, Flex } from "@react-native-material/core";
import { Text } from "react-native-paper";

const All = () => {
    return (
        <Box>
            <Text style={{ fontSize: 20, margin: "auto" }}>Hello, Welcome to All Page.</Text>
        </Box>
    )
}

export default All;