import React, { useState, useEffect } from "react";
import { Box, Flex } from "@react-native-material/core";
import { Text } from "react-native-paper";
const Hot = () => {
    return (
        <Box>
            <Text style={{ fontSize: 20, margin: "auto" }}>
                Hello, Welcome to Hot Page.
            </Text>
        </Box>
    )
}

export default Hot;