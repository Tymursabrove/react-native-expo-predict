export type PrivacyProps = {
  themeMode: string
}

export type TermProps = {
  themeMode: string
}
