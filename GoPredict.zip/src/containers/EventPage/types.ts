export type Props = {
  themeMode: string
};

