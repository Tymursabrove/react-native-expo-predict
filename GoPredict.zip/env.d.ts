declare module "@env" {
  export const ENV_VAR: string;
}
