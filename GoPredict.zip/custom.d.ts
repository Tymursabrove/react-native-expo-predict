declare module "*.png" {
    //const content: React.FunctionComponent<React.SVGAttributes<SVGElement>>;
    const content: string;
    export default content;
}